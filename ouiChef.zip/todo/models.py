from django.db import models

# Create your models here.
class TodoItem(models.Model):
    content = models.TextField()
    # date_created
    # author

class EngageItem(models.Model):
    content = models.TextField()

class RecipeList(models.Model):
    content = "Chicken pot pie"
    date_created = "4/2/2021"
    author = "Spencer Eckler"