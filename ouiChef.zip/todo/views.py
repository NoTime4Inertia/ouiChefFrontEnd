from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from .models import TodoItem, EngageItem, RecipeList
from copy import copy
import csv
import pandas as pd


# Create your views here.
def todoView(request):
    all_todo_items = TodoItem.objects.all()
    return render(request, 'todo.html', 
        {'all_items': all_todo_items}) # recall curly brackets means dict.

def addTodo(request):
    c = request.POST['content'] # from the request retrieve the thing called content
    new_item = TodoItem(content = c)
    new_item.save()
    return HttpResponseRedirect('/todo/')

def deleteTodo(request, todo_id):
    item_to_delete = TodoItem.objects.get(id=todo_id)
    item_to_delete.delete()
    return HttpResponseRedirect('/todo/')

def engage(request):
    all_engage_items = copy(TodoItem.objects.all())
    return render(request, 'todo.html', 
        {'engage_items': all_engage_items})

def recipeList(request):
    # create the httpresponse object with the appropriate csv header
    csv_data = pd.read_csv('Book1.csv')

    response = render(request, 'todo.html', {'data': csv_data})
    
    # load db
    return response

#def recipeList(request):
#    df = pd.read_csv('C:/Users/nh_or/django/Book1.csv')
#    return render(request, 'todo.html', {'columns': df.columns, 'rows': df.to_dict('records')})